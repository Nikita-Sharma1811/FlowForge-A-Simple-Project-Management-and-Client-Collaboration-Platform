import React from 'react'

export default function Settings() {
    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold">Settings</h1>
        </div>
    )
}